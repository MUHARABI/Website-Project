/// @file prqueue.h
/// @author Muhammed Arabi
/// @date October 20, 2023
///
/// Assignment details and provided code are created and
/// owned by Adam T Koehler, PhD - Copyright 2023.
/// University of Illinois Chicago - CS 251 Fall 2023

//file name: prqueue.h
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 4: Priority Queue
//this files contains the prqueue class that contains all its private and public member functions
//program takes trees and manipulates, compares, and evaluates all types of aspects including size, value, priority.

#pragma once

#include <iostream>
#include <sstream>
#include <set>

using namespace std;

template<typename T>
class prqueue {
private:
    struct NODE {
        int priority;  // used to build BST
        T value;       // stored data for the p-queue
        bool dup;      // marked true when there are duplicate priorities
        NODE* parent;  // links back to parent
        NODE* link;    // links to linked list of NODES with duplicate priorities
        NODE* left;    // links to left child
        NODE* right;   // links to right child
    };
    NODE* root; // pointer to root node of the BST
    int sz;     // # of elements in the prqueue
    NODE* curr; // pointer to next item in prqueue (see begin and next)

    //Helper functions: 

    // Function to copy tree from node using recursion.
    NODE* copyTree(NODE* node) {
        //base case if node is null
        if (node == nullptr) {
            return nullptr;
        }
        //creates newNode with same information as in node:
        NODE* newNode = new NODE;
        newNode->priority = node->priority;
        newNode->value = node->value;
        newNode->dup = node->dup;
        newNode->parent = nullptr;
        newNode->link = nullptr;
        newNode->left = nullptr;
        newNode->right = nullptr;

        //update newNode by Recursively copying the left, right, and linked list nodes.
        newNode->left = copyTree(node->left);
        newNode->right = copyTree(node->right);
        newNode->link = copyTree(node->link);
        //returns updated newNode:
        return newNode;
    }

    
    //Function to clear tress from root using recursion.
    void clearTree(NODE* node) {
        if (node != nullptr) {
            //recursivly clear left, right and link nodes
            clearTree(node->left);
            clearTree(node->right);
            clearTree(node->link);
            //free current node memory:
            delete node;
        }
    }

    //function to find minimum node from left side of tree:
    NODE* findMin(NODE* node) {
        //Base case if the node is null:
        if (node == nullptr) {
            return nullptr;
        }
        //Traverse to the left most node to find the minimum value.
        NODE* current = node;
        while (current->left != nullptr) {
            current = current->left;
        }
        //return left most node:
        return current;
    }
    //Function that does a traversal in order, and stores the nodes in a stringstream:
    void Traversal(NODE* node, stringstream& ss) {
        //base case, if node is null:
        if (node == nullptr) {
            return;
        }
        // traverse the left side of the tree recursivly.
        Traversal(node->left, ss);
    
        // Output current node priority and value:
        ss << node->priority << " value: " << node->value << "\n";
    
        // Traverse the linked list of nodes 
        NODE* temp = node->link;
        while (temp != nullptr) {
            ss << temp->priority << " value: " << temp->value << "\n";
            temp = temp->link;
        }
        //Now traverses the right side of tree recursivly.
        Traversal(node->right, ss);
    }
    //Function to compare two trees for equality recursivley.
    //helper function for bool operator== function
    bool compareTrees(NODE* tree1, NODE* tree2) const {
        // Base case: if both nodes are null, they are equal, return true
        if (tree1 == nullptr && tree2 == nullptr) {
            return true;
        }
        //base case2: if one is null and the other isnt, they are not equal, return false
        if (tree1 == nullptr || tree2 == nullptr) {
            return false;
        }
        // base case 3: if the priority, value, or dup nodes arent equal, then return false:
        if (tree1->priority != tree2->priority || tree1->value != tree2->value || tree1->dup != tree2->dup) {
            return false;
        }
        // Compare the current nodes and their left, right, and linked list nodes recursively.
        return compareTrees(tree1->left, tree2->left) && compareTrees(tree1->right, tree2->right) && compareTrees(tree1->link, tree2->link);
    }
    


    
    
public:
    //
    // default constructor:
    //
    // Creates an empty priority queue.
    // O(1)

    //default contructor function, sets root and curr = null and size is 0:
    prqueue() {
        root = nullptr;
        sz = 0;
        curr = nullptr;
    }
    
    //
    // operator=
    //
    // Clears "this" tree and then makes a copy of the "other" tree.
    // Sets all member variables appropriately.
    // O(n), where n is total number of nodes in custom BST

    //copy assignment operator:
    prqueue& operator=(const prqueue& other) {
        if (this != &other) {
            // Clear the current tree.
            clear();
            // Copy other tree to the current tree.
            root = copyTree(other.root);
            // Set size to the size of the other tree.
            sz = other.sz;
            // set the curr pointer to null.
            curr = nullptr;
        }
        //return current object
        return *this;
    }
    
    //
    // clear:
    //
    // Frees the memory associated with the priority queue but is public.
    // O(n), where n is total number of nodes in custom BST

    //frees memeory and sets root and size back to null and 0:
    void clear() {
        //calls clear tree helper function:
        clearTree(root);
        //resets root and size
        root = nullptr;
        sz = 0;
    }
    
    //
    // destructor:
    //
    // Frees the memory associated with the priority queue.
    // O(n), where n is total number of nodes in custom BST

    //destructor function:
    ~prqueue() {
        //clears tree:
        clearTree(root);
    }
        
    //
    // enqueue:
    //
    // Inserts the value into the custom BST in the correct location based on
    // priority.
    // O(logn + m), where n is number of unique nodes in tree and m is number 
    // of duplicate priorities
    //
    void enqueue(T value, int priority) {
        NODE* Tree = new NODE(); 
       

        // assign priority, dup, and value for the new node
        Tree->priority= priority;
        Tree->dup =false;
        Tree->value = value;
        
        
        // Initialize pointers for temporary and previous node
        NODE* tmp = root;
        NODE* Prev = nullptr;

        // Traverse the tree to find the correct position for the new node.
        while (tmp != nullptr){ 

            // If the priority matches with the current node's priority, assign duplicate
            if (priority == tmp->priority){ 
                Tree->dup=true; 

                // Traverse to the last node with the same priority value
                while (tmp->link){ 
                    tmp = tmp->link;
                }

                // Link the new node to the last node with the same priority
                tmp->link = Tree;
                Tree->parent = tmp;

                //set all child ptrs to null
                Tree->link = nullptr;
                Tree->left = nullptr;
                Tree->right = nullptr;
                //size gets incremented
                sz++;

                //exit function
                return;
            }
            // If the given priority is less than the current node's priority then go left
            if (priority < tmp->priority){ 
                Prev = tmp;
                tmp = tmp->left;
            }   
            else{  // If the given priority is greater than the current node's priority, go right
                
                Prev = tmp;
                tmp = tmp->right;
            }
        // If the tree is empty, set the new node as the root
        }
        if (Prev == nullptr){
            root = Tree;
        } // If priority is less than the previous node's priority, go left
        else if(priority < Prev->priority){
            Prev->left = Tree;
        } // If priority is greater than the previous node's priority, insert on the right
        else{
            Prev->right = Tree;
        }
        Tree->parent = Prev;

        //reset node pointer in both direction to null:
        Tree->right = nullptr;
        Tree->left = nullptr;
        
        //increment size
        ++sz;
    }



    //
    // dequeue:
    //
    // returns the value of the next element in the priority queue and removes
    // the element from the priority queue.
    // O(logn + m), where n is number of unique nodes in tree and m is number 
    // of duplicate priorities
    //
    T dequeue() {
        //base case, if tree is empty then throw error:
        if(root == nullptr){
            throw out_of_range("empty");
        }
        // Initialize pointers for node to be erased and its parent
        NODE* erase = root;
        NODE* parent = nullptr;

        // Traverse the tree to find the left most node or node with smallest priority.
        while(erase->left != nullptr){
            parent = erase;
            erase = erase->left;
        }

        // Store the value of the most left node in valueOut
        T valueOut = erase->value;

        // If the leftmost node has duplicates 
        if(erase->link != nullptr){
            // Move the data from the tmp node to the most left node
            NODE* tmp = erase->link;
            erase->value = tmp->value;
            erase->priority = tmp->priority;
            erase->link = tmp->link;
            // Delete tmp node
            delete tmp;
        }// If the leftmost node doesn't have duplicates, update parent left pointer
        else{
            if(parent == nullptr){
                root = erase->right;
            }else{
                parent->left = erase->right;
            }
            //delete most left node
            delete erase;
        }
        //decrement size
        sz--;
        //return the most left node value
        return valueOut;
    }









    
    //
    // Size:
    //
    // Returns the # of elements in the priority queue, 0 if empty.
    // O(1)
    //

    //function that returs size of tree:
    int size() {
        return sz;
    }
    
    //
    // begin
    //
    // Resets internal state for an inorder traversal.  After the
    // call to begin(), the internal state denotes the first inorder
    // node; this ensure that first call to next() function returns
    // the first inorder node value.
    //
    // O(logn), where n is number of unique nodes in tree
    //
    // Example usage:
    //    pq.begin();
    //    while (tree.next(value, priority)) {
    //      cout << priority << " value: " << value << endl;
    //    }
    //    cout << priority << " value: " << value << endl;

    //function that finds starting point using left most min value:
    void begin() {
        //traverses through root and sets the smallest value to curr to assign start point
        if (root != nullptr) {
            curr = findMin(root);
        }
    }

    
    //
    // next
    //
    // Uses the internal state to return the next inorder priority, and
    // then advances the internal state in anticipation of future
    // calls.  If a value/priority are in fact returned (via the reference
    // parameter), true is also returned.
    //
    // False is returned when the internal state has reached null,
    // meaning no more values/priorities are available.  This is the end of the
    // inorder traversal.
    //
    // O(logn), where n is the number of unique nodes in tree
    //
    // Example usage:
    //    pq.begin();
    //    while (pq.next(value, priority)) {
    //      cout << priority << " value: " << value << endl;
    //    }
    //    cout << priority << " value: " << value << endl;
    //
    bool next(T& value, int &priority) {
        //base case, if curr is null, return false
        if (curr == nullptr){
            return false; 
        }

        // assign the priority and value of the current node
        priority = curr->priority;
        value = curr->value;

         // If the current node has nodes equal priority
        if (curr->link){ 
            // shift to the next linked node and return true
            curr = curr->link;
            return true;
        }
         //traverse up the tree while current node has duplicates 
        while (curr->dup){ 
            curr = curr->parent;
        }//If the current node has a right child:
        if (curr->right){
            //move to the right child and then traverse to the most left node
            curr = curr->right;
            while (curr->left){
                curr = curr->left;
            }
            return true;
        } //traverse up the tree until a node with a greater priority is found
        while (curr->parent){ 
            curr = curr->parent;
             //If a node with a greater priority is found, return true
            if (curr->priority > priority){
                return true;
            }
        }
        //If there are no more nodes, set curr to null and return false
        curr = nullptr;
        return false; 
    }


    
    //
    // toString:
    //
    // Returns a string of the entire priority queue, in order.  Format:
    // "1 value: Ben
    //  2 value: Jen
    //  2 value: Sven
    //  3 value: Gwen"
    //
    string toString() {
        string str = "";
        //Create a stringstream object to allow for string conversion
        stringstream ss;
        //Call the Traversal function to perform an inorder traversal and update stringstream
        Traversal(root, ss);
        //convert stringstream to string
        str = ss.str();
        //Return the final string
        return str;
    }
    
    //
    // peek:
    //
    // returns the value of the next element in the priority queue but does not
    // remove the item from the priority queue.
    // O(logn + m), where n is number of unique nodes in tree and m is number 
    // of duplicate priorities
    //
    T peek() {
        T valueOut; 
        //base case: if empty, throw error:
        if (root == nullptr) {
            
            throw out_of_range("Empty");
        }
        //intiallize and set cur to roor
        NODE* curr = root;
        //loop through left side of curr tree
        while(curr->left != nullptr){
            curr = curr->left;
        }
        //return value
        
        valueOut = curr->value;
        return valueOut;
    }
    
    //
    // ==operator
    //
    // Returns true if this priority queue as the priority queue passed in as
    // other.  Otherwise returns false. 
    // O(n), where n is total number of nodes in custom BST

    //compares other and root to check for equality:
    bool operator==(const prqueue& other) const {
        //calls helper function to compare root and other tree
        return compareTrees(root, other.root);
    }
    
    //
    // getRoot - Do not edit/change!
    //
    // Used for testing the BST.
    // return the root node for testing.
    //
    void* getRoot() {
        return root;
    }


 
    

    

};
