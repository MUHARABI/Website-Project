/// @file tests.cpp
/// @author Muhammed Arabi
/// @date October 20, 2023

//file name: tests.cpp
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 4: Priority Queue
//this file tests the public member functions of prqueue.h in various different
//includes edge cases and variety of different inputs and examples;


/// Provided testing file to implement framework based tests in. The examples
/// below demonstrates a basic empty test in each framework with a single
/// assertion. The version uses the supplied catch.hpp file in starter code.
///
/// Assignment details and provided code are created and
/// owned by Adam T Koehler, PhD - Copyright 2023.
/// University of Illinois Chicago - CS 251 Fall 2023

// Catch 2.x - Single Include Framework Testing
#define CATCH_CONFIG_MAIN

#include "prqueue.h"
#include "catch.hpp"

using namespace std;

// This is a basic test case example with sections.
// Requires: <no oter functions>
TEST_CASE("Test 0: The Null Test") 
{
    // In this section we test Scenario 1.
    SECTION("Test 0: Empty Truths")
    {
        REQUIRE(true == true);
    }

    // In this section we test Scenario 2.
    SECTION("Test 0: Empty Falsehoods")
    {
        REQUIRE(false == false);
    }
}


// Test case for queue with unique priorities
TEST_CASE("Test 1: Unique Priorities")
{
    prqueue<string> pq;
    pq.enqueue("Josh", 3);
    pq.enqueue("Jack", 1);
    pq.enqueue("Sarah", 5);

    SECTION("")
    {
        REQUIRE(pq.size() == 3);
    }

    SECTION("")
    {
        REQUIRE(pq.peek() == "Jack");
    }

    SECTION("")
    {
        REQUIRE(pq.dequeue() == "Jack");
        REQUIRE(pq.dequeue() == "Josh");
        REQUIRE(pq.dequeue() == "Sarah");
    }

    SECTION("")
    {
        REQUIRE(pq.toString() == "1 value: Jack\n3 value: Josh\n5 value: Sarah\n");
    }
}

// Test case for queue with duplicate priorities
TEST_CASE("Test 2: Duplicate Priorities ")
{
    prqueue<int> pq;
    pq.enqueue(10, 2);
    pq.enqueue(20, 1);
    pq.enqueue(30, 2);
    pq.enqueue(40, 1);
    pq.enqueue(50, 3);

    SECTION("")
    {
        REQUIRE(pq.size() == 5);
    }

    SECTION("")
    {
        REQUIRE(pq.peek() == 20);
    }

    SECTION("")
    {
        REQUIRE(pq.dequeue() == 20);
        REQUIRE(pq.dequeue() == 40);
        REQUIRE(pq.dequeue() == 10);
        REQUIRE(pq.dequeue() == 30);
        REQUIRE(pq.dequeue() == 50);
    }

    SECTION("")
    {
        REQUIRE(pq.toString() == "1 value: 20\n1 value: 40\n2 value: 10\n2 value: 30\n3 value: 50\n");
    }
}

// Test case for equality operator
TEST_CASE("Test 3: Operator")
{
    prqueue<string> pq1;
    pq1.enqueue("A", 1);
    pq1.enqueue("B", 2);
    pq1.enqueue("C", 3);

    prqueue<string> pq2;
    pq2.enqueue("A", 1);
    pq2.enqueue("B", 2);
    pq2.enqueue("C", 3);

    prqueue<string> pq3;
    pq3.enqueue("X", 1);
    pq3.enqueue("Y", 2);
    pq3.enqueue("Z", 3);

    SECTION("")
    {
        REQUIRE(pq1 == pq2);
    }

    SECTION("")
    {
        REQUIRE_FALSE(pq1 == pq3);
    }
}
TEST_CASE("Test 4:  Queue Operations")
{
    prqueue<int> pq;

    SECTION("")
    {
        REQUIRE(pq.size() == 0);
    }

    

    SECTION("")
    {
        pq.enqueue(100, 2);
        pq.enqueue(200, 1);
        pq.enqueue(300, 3);
        pq.enqueue(400, 2);
        pq.enqueue(500, 1);

        REQUIRE(pq.size() == 5);

        REQUIRE(pq.peek() == 200);
        REQUIRE(pq.dequeue() == 200);

        REQUIRE(pq.peek() == 500);
        REQUIRE(pq.dequeue() == 500);

        REQUIRE(pq.peek() == 100);
        REQUIRE(pq.dequeue() == 100);

        REQUIRE(pq.peek() == 400);
        REQUIRE(pq.dequeue() == 400);

        REQUIRE(pq.peek() == 300);
        REQUIRE(pq.dequeue() == 300);

        REQUIRE(pq.size() == 0);
    }

    SECTION("")
    {
        pq.enqueue(100, 1);
        pq.enqueue(200, 2);
        pq.enqueue(300, 1);
        pq.enqueue(400, 2);
        pq.enqueue(500, 3);

        REQUIRE(pq.size() == 5);

        REQUIRE(pq.peek() == 100);
        REQUIRE(pq.dequeue() == 100);

        REQUIRE(pq.peek() == 300);
        REQUIRE(pq.dequeue() == 300);

        REQUIRE(pq.peek() == 200);
        REQUIRE(pq.dequeue() == 200);

        REQUIRE(pq.peek() == 400);
        REQUIRE(pq.dequeue() == 400);

        REQUIRE(pq.peek() == 500);
        REQUIRE(pq.dequeue() == 500);

        REQUIRE(pq.size() == 0);
    }

    SECTION("")
    {
        REQUIRE(pq.toString() == "");
    }

    SECTION("")
    {
        pq.enqueue(100, 1);
        pq.enqueue(200, 2);
        pq.enqueue(300, 1);
        pq.enqueue(400, 2);
        pq.enqueue(500, 3);

        REQUIRE(pq.toString() == "1 value: 100\n1 value: 300\n2 value: 200\n2 value: 400\n3 value: 500\n");
    }
}
TEST_CASE("Test 5: Next Functionality")
{
    prqueue<int> pq;
    pq.enqueue(15, 2);
    pq.enqueue(25, 1);
    pq.enqueue(35, 2);
    pq.enqueue(45, 1);
    pq.enqueue(55, 3);

    // Check next() for an empty queue
    SECTION("")
    {
        prqueue<int> emptyPQ;
        int value;
        int priority;
        REQUIRE_FALSE(emptyPQ.next(value, priority));
    }

   
    SECTION("")
    {
        int expectedValues[] = {25, 15, 35, 45, 55};
        int expectedPriorities[] = {1, 2, 2, 1, 3};

        int index = 0;
        int value;
        int priority;

        // make sure that next() returns true  
        while (pq.next(value, priority))
        {
            REQUIRE(value == expectedValues[index]);
            REQUIRE(priority == expectedPriorities[index]);
            index++;
        }

        // After reaching the end, next() should return false
        REQUIRE_FALSE(pq.next(value, priority));
    }

    // Check next() for a  queue with duplicate priorities
    SECTION("")
    {
        prqueue<int> duplicatePQ;
        duplicatePQ.enqueue(15, 2);
        duplicatePQ.enqueue(25, 1);
        duplicatePQ.enqueue(35, 2);
        duplicatePQ.enqueue(45, 1);
        duplicatePQ.enqueue(55, 3);

        int expectedValues[] = {25, 45, 15, 35, 55};
        int expectedPriorities[] = {1, 1, 2, 2, 3};

        int index = 0;
        int value;
        int priority;

        
        while (duplicatePQ.next(value, priority))
        {
            REQUIRE(value == expectedValues[index]);
            REQUIRE(priority == expectedPriorities[index]);
            index++;
        }

        
        REQUIRE_FALSE(duplicatePQ.next(value, priority));
    }
}
// Test case for dequeue() on an empty 
TEST_CASE("Test 6: Dequeue on Empty Queue")
{
    prqueue<int> pq;

    SECTION("")
    {
        REQUIRE_THROWS_AS(pq.dequeue(), out_of_range);
    }
}


// Test case for operator== 
TEST_CASE("Test 7: Operator")
{
    prqueue<string> pq1;
    pq1.enqueue("F", 1);
    pq1.enqueue("B", 2);
    pq1.enqueue("M", 3);

    prqueue<string> pq2;
    pq2.enqueue("F", 1);
    pq2.enqueue("B", 2);
    pq2.enqueue("M", 3);

    prqueue<string> pq3;
    pq3.enqueue("X", 1);
    pq3.enqueue("Y", 2);
    pq3.enqueue("Z", 3);

    SECTION("")
    {
        REQUIRE(pq1 == pq2);
    }

    SECTION("")
    {
        REQUIRE_FALSE(pq1 == pq3);
    }
}
// Test case for edge case: single element queue
TEST_CASE("Test 8: Single Element Queue")
{
    prqueue<int> pq;
    pq.enqueue(22, 1);

    SECTION("")
    {
        REQUIRE(pq.size() == 1);
    }

    SECTION("")
    {
        REQUIRE(pq.peek() == 22);
        REQUIRE(pq.dequeue() == 22);
    }
}
// Test case for boundary values
TEST_CASE("Test 9: edge cases")
{
    prqueue<int> pq;

    SECTION("")
    {
        REQUIRE_THROWS_AS(pq.dequeue(), out_of_range);
    }
}
TEST_CASE("Test 10: ")
{
    prqueue<int> pq;
    pq.begin();
    int value;
    int priority;
    REQUIRE_FALSE(pq.next(value, priority)); 
}
TEST_CASE("Test 11: ")
{
    prqueue<int> pq;
    pq.enqueue(19, 2);
    pq.enqueue(20, 1);
    pq.enqueue(21, 3);
    pq.begin();
    int value;
    int priority;
    REQUIRE(pq.next(value, priority)); 
    REQUIRE(value == 20); 
    REQUIRE(priority == 1);
}
TEST_CASE("Test 12: ")
{
    prqueue<int> pq;
    pq.clear();
    REQUIRE(pq.size() == 0); 
}
TEST_CASE("Test 13: ")
{
    prqueue<int> pq;
    pq.enqueue(8, 2);
    pq.enqueue(9, 1);
    pq.enqueue(10, 3);
    pq.clear();
    REQUIRE(pq.size() == 0); 
    int value;
    int priority;
    REQUIRE_FALSE(pq.next(value, priority)); 
}
TEST_CASE("Test 14: Clear/enqueue more tests")
{
    prqueue<int> pq;
    pq.enqueue(12, 2);
    pq.enqueue(23, 1);
    pq.enqueue(35, 3);
    pq.clear();
    pq.enqueue(47, 4);
    REQUIRE(pq.size() == 1); 
   
}
TEST_CASE("Test 15: more tests")
{
    prqueue<int> pq;
    pq.enqueue(1, 2);
    pq.enqueue(2, 1);
    pq.enqueue(3, 2);
    pq.enqueue(4, 1);
    pq.enqueue(5, 3);

    SECTION("")
    {
        REQUIRE(pq.size() == 5);
    }

    SECTION("")
    {
        REQUIRE(pq.peek() == 2);
        REQUIRE(pq.size() == 5);
    }

    
    SECTION("")
    {
        pq.clear();
        REQUIRE(pq.size() == 0);
        int value;
        int priority;
        REQUIRE_FALSE(pq.next(value, priority));
    }

    SECTION("")
    {
        prqueue<int> copiedPQ;
        copiedPQ = pq;
        REQUIRE(copiedPQ.size() == 5);
        int value;
        int priority;
        int expectedValues[] = {2, 1, 3, 4, 5};
        int expectedPriorities[] = {1, 2, 2, 1, 3};
        int index = 0;

        // makes sure that next() returns true and provides correct values in correct order for copied queue
        while (copiedPQ.next(value, priority))
        {
            REQUIRE(value == expectedValues[index]);
            REQUIRE(priority == expectedPriorities[index]);
            index++;
        }

        // After reaching the end, next() should return false for copied queue
        REQUIRE_FALSE(copiedPQ.next(value, priority));
    }
}



TEST_CASE("Test 16: more tests for Equality Operator")
{
    prqueue<int> pq1;
    pq1.enqueue(10, 2);
    pq1.enqueue(20, 1);
    pq1.enqueue(30, 2);

    prqueue<int> pq2;
    pq2.enqueue(10, 2);
    pq2.enqueue(20, 1);
    pq2.enqueue(30, 2);

    prqueue<int> pq3;
    pq3.enqueue(15, 2);
    pq3.enqueue(20, 1);
    pq3.enqueue(30, 2);

    prqueue<int> pq4;
    pq4.enqueue(10, 1);
    pq4.enqueue(20, 2);
    pq4.enqueue(30, 2);

    prqueue<int> pq5;
    pq5.enqueue(10, 2);
    pq5.enqueue(20, 1);
    pq5.enqueue(30, 2);
    pq5.enqueue(40, 3);

    SECTION("")
    {
        REQUIRE(pq1 == pq2);
    }

    SECTION("")
    {
        REQUIRE_FALSE(pq1 == pq3);
        REQUIRE_FALSE(pq1 == pq4);
        REQUIRE_FALSE(pq1 == pq5);
    }
}

TEST_CASE("Test 17: more tests")
{
    prqueue<int> pq;
    pq.enqueue(150, 2);
    pq.enqueue(200, 1);
    pq.enqueue(350, 3);
    pq.clear();
    pq.enqueue(450, 4);
    REQUIRE(pq.size() == 1);
    REQUIRE(pq.peek() == 450);
}

TEST_CASE("Test 18: Assignment Operator")
{
    prqueue<int> pq1;
    pq1.enqueue(10, 2);
    pq1.enqueue(20, 1);
    pq1.enqueue(30, 2);

    prqueue<int> pq2;
    pq2.enqueue(40, 3);
    pq2.enqueue(50, 1);

    pq2 = pq1;

    int value;
    int priority;
    int expectedValues[] = {20, 10, 30};
    int expectedPriorities[] = {1, 2, 2};
    int index = 0;

    
    while (pq2.next(value, priority))
    {
        REQUIRE(value == expectedValues[index]);
        REQUIRE(priority == expectedPriorities[index]);
        index++;
    }

    
    REQUIRE_FALSE(pq2.next(value, priority));
}
TEST_CASE("Test 20: ")
{
    prqueue<int> pq;
    int value;
    int priority;
    
   
    REQUIRE_FALSE(pq.next(value, priority));
}

TEST_CASE("Test 21: ")
{
    prqueue<int> pq;
    pq.enqueue(10, 2);
    pq.enqueue(20, 1);
    pq.enqueue(30, 3);
    pq.enqueue(40, 1);
    pq.enqueue(50, 3);

    int expectedValues[] = {20, 40, 10, 30, 50};
    int expectedPriorities[] = {1, 1, 2, 3, 3};
    int index = 0;
    int value;
    int priority;

    SECTION("")
    {
        
        while (pq.next(value, priority))
        {
            REQUIRE(value == expectedValues[index]);
            REQUIRE(priority == expectedPriorities[index]);
            index++;
        }

       
        REQUIRE_FALSE(pq.next(value, priority));
    }

    
}

TEST_CASE("Test 22: ")
{
    prqueue<string> pq;
    pq.enqueue("Max", 3);
    pq.enqueue("Justin", 1);
    pq.enqueue("Lucas", 5);

    SECTION("")
    {
        
        REQUIRE(pq.size() == 3);
    }

    SECTION("")
    {
        
        REQUIRE(pq.peek() == "Justin");
    }

    SECTION("")
    {
       
        REQUIRE(pq.dequeue() == "Justin");
        REQUIRE(pq.dequeue() == "Max");
        REQUIRE(pq.dequeue() == "Lucas");
    }

    SECTION("")
    {
        
        REQUIRE(pq.toString() == "1 value: Justin\n3 value: Max\n5 value: Lucas\n");
    }

    SECTION("")
    {
        
        pq.dequeue();
        pq.dequeue();
        pq.dequeue();
        REQUIRE(pq.size() == 0);
    }
}
TEST_CASE("Test 23")
{
    prqueue<int> pq;
    pq.enqueue(117, 2);
    pq.enqueue(229, 1);
    pq.enqueue(356, 3);
    pq.enqueue(423, 1);
    pq.enqueue(565, 3);

    SECTION("")
    {
       
        REQUIRE(pq.size() > 0);
    }

    SECTION("")
    {
        
        pq.clear();
        REQUIRE(pq.size() == 0);
    }

    SECTION("")
    {
        
        pq.clear();
        REQUIRE(pq.size() == 0);
        int value;
        int priority;
    
        REQUIRE_FALSE(pq.next(value, priority));
    }
}

TEST_CASE("Test 24")
{
    prqueue<string> original;
    original.enqueue("Alex", 3);
    original.enqueue("Armando", 1);
    original.enqueue("Martha", 5);

    prqueue<string> copy(original);

    SECTION("")
    {
        
        REQUIRE(copy.size() == original.size());

       
        REQUIRE(copy.peek() == original.peek());

        
    }

    SECTION("")
    {
       
        copy.dequeue();
        copy.dequeue();
        copy.dequeue();

       
        REQUIRE(original.size() == 3);
        REQUIRE(original.peek() == "Alex");
    }
}

TEST_CASE("Test 25:")
{
    prqueue<string> original;
    original.enqueue("Alex", 3);
    original.enqueue("Carlos", 1);
    original.enqueue("Richard", 5);

    prqueue<string> copy;
    copy.enqueue("Diana", 2);
    copy.enqueue("Jesse", 4);

   
    copy = original;

    SECTION("")
    {
        
        REQUIRE(copy.size() == original.size());

        
        REQUIRE(copy.peek() == original.peek());

        
        REQUIRE(copy.dequeue() == original.dequeue());
        REQUIRE(copy.dequeue() == original.dequeue());
        REQUIRE(copy.dequeue() == original.dequeue());
    }

    SECTION("")
    {
        
        copy.dequeue();
        copy.dequeue();
        copy.dequeue();

        
        REQUIRE(original.size() == 3);
        REQUIRE(original.peek() == "Carlos");
    }
}

TEST_CASE("Test 26")
{
    prqueue<int> pq;
    pq.enqueue(78, 2);
    pq.enqueue(92, 1);

    
    pq = pq;

    SECTION("")
    {
        
        REQUIRE(pq.size() == 2);

       
        REQUIRE(pq.peek() == 92);

       
        REQUIRE(pq.dequeue() == 92);
        REQUIRE(pq.dequeue() == 78);
    }
}

TEST_CASE("Test 27")
{
    prqueue<string> original;
    original.enqueue("Joey", 3);
    original.enqueue("Allan", 1);
    original.enqueue("Laura", 5);

    prqueue<string> moved(std::move(original));

    SECTION("")
    {
        REQUIRE(moved.size() == 3);
        REQUIRE(moved.peek() == "Allan");

        
        REQUIRE(moved.dequeue() == "Allan");
        REQUIRE(moved.dequeue() == "Joey");
        REQUIRE(moved.dequeue() == "Laura");
    }
}

















