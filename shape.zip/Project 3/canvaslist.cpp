
//file name: canvaslist.cpp
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 3: Shape list project
//this file implements the shapeNode and canvasList classes intialized in Canvaslist.h 
//and returns the shape and node adresses as well as the updated list of shapes after
//various manipulations and changes.

#include "canvaslist.h"
#include "shape.h"
#include <iostream>

using namespace std;
CanvasList::CanvasList(){
    listSize = 0; 
    listFront = nullptr;
}

// Copy Constructor
CanvasList::CanvasList(const CanvasList& other){
    listSize =0;
    listFront = nullptr;
    ShapeNode* otherCurrent = nullptr;
    
    for(ShapeNode* otherNode = other.listFront; otherNode != nullptr; otherNode = otherNode->next){
        Shape* copyShape = otherNode->value->copy();
        ShapeNode* newNode = new ShapeNode;
        newNode->value = copyShape;
        newNode->next = nullptr;

        if(otherCurrent){
            otherCurrent->next = newNode;
        }
        else{
            listFront = newNode;
        }
        listSize++;
        otherCurrent = newNode;
    }
}

// Copy Assignment Operator
CanvasList& CanvasList::operator=(const CanvasList& other) {
    if (this != &other) {
        clear();
        
        ShapeNode* otherCurrent = other.listFront;
        while (otherCurrent != nullptr) {
            Shape* shapeCopy = new Shape(*(otherCurrent->value));
            push_back(shapeCopy);
            otherCurrent = otherCurrent->next;  
        }
        
    }
    return *this;
}

//destructor
CanvasList::~CanvasList() {
    clear();
}
//clears the list of shapes to avoid memory leaks
void CanvasList::clear() {
    while (listFront != nullptr) {
        ShapeNode* temp = listFront;
        listFront = listFront->next;
        delete temp->value; 
        delete temp; 
    }
    listSize =0;
} 
//Inserts shape after certain index:
void CanvasList::insertAfter(int index, Shape* shape) {
    if (index < 0 || index >= listSize) {
        return;
    }
    ShapeNode* newNode = new ShapeNode();
    newNode->value = shape;

    if (index == listSize - 1) {
        ShapeNode* current = listFront;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    } else {
        ShapeNode* current = listFront;
        for (int i = 0; i < index; ++i) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }

    ++listSize;
}
//Adds a shape to the front of the list
void CanvasList::push_front(Shape* shape) {
    ShapeNode* newNode = new ShapeNode();
    newNode->value = shape;
    newNode->next = listFront;
    listFront = newNode;
    ++listSize;
}
//adds shape to the back of the list
void CanvasList::push_back(Shape* shape) {
    ShapeNode* newNode = new ShapeNode();
    newNode->value = shape;
    newNode->next = nullptr;

    if (listFront == nullptr) {
        // If the list is empty then the new node becomes the front
        listFront = newNode;
    } else {
        // else find the last node and add the new node after it
        ShapeNode* current = listFront;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }
    
    ++listSize;
}
//Remove a shape at a certain index
void CanvasList::removeAt(int index) {
    if (index < 0 || index >= listSize || isempty()) {
       
        return;
    }
    ShapeNode* temp = nullptr;
    if (index == 0) {
       
        temp = listFront;
        listFront = listFront->next;
    } else {
        ShapeNode* current = listFront;
        for (int i = 0; i < index - 1; ++i) {
            current = current->next;
        }
        if(current->next){
            temp = current->next;
            current->next = temp->next;
        }
    }
    delete temp->value;
    delete temp;
    --listSize;
}
//removes every other shape from a list
void CanvasList::removeEveryOther() {
    ShapeNode* current = listFront;
    while (current != nullptr && current->next != nullptr) {
        ShapeNode* temp = current->next;
        current->next = temp->next;
        delete temp->value;
        delete temp;
        current = current->next;
        --listSize;
    }
}
//remove and returns first shape in the list
Shape* CanvasList::pop_front() {
    if (isempty()) {
        return nullptr;
    }

    ShapeNode* temp = listFront;
    Shape* shape = temp->value;
    listFront = listFront->next;
    delete temp;
    --listSize;
    return shape;
}
//remove and return the last shape in the list
Shape* CanvasList::pop_back() {
    if (isempty()) {
        
        return nullptr;
    }

    if (listFront->next == nullptr) {
        // Only one node in the list
        Shape* shape = listFront->value;
        delete listFront;
        
        listFront = nullptr;
        --listSize;
        return shape;
    }

    ShapeNode* current = listFront;
    while (current->next->next != nullptr) {
        current = current->next;
    }

    Shape* shape = current->next->value;
    delete current->next;
    current->next = nullptr;
    --listSize;
    return shape;
}
//returns front node of linked list
ShapeNode* CanvasList::front() const {
   return listFront;
}
//checks to see if linked list is empty
bool CanvasList::isempty() const {
    return listSize == 0;
}
//gets the size of list
int CanvasList::size() const {
    return listSize;
}
//find a shape's index based on its x and y values
int CanvasList::find(int x, int y) const {
    ShapeNode* current = listFront;
    for (int i = 0; i < listSize; ++i) {
        if (current->value->getX() == x && current->value->getY() == y) {
            return i;
        }
        current = current->next;
    }
    return -1;
}
//gets the shape at a certain index
Shape* CanvasList::shapeAt(int index) const {
    if (index < 0 || index >= listSize) {
        // Invalid index
        return nullptr;
    }
    ShapeNode* current = listFront;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    return current->value;
}
//draws the shapes from the list
void CanvasList::draw() const {
    ShapeNode* current = listFront;
    while (current != nullptr) {
        cout << current->value->printShape() << endl;
        current = current->next;
    }
}
//prints node addresses and shape adresses in list
void CanvasList::printAddresses() const {
    ShapeNode* current = listFront;
    while (current != nullptr) {
        cout << "Node Address: " << current << "\tShape Address: " << current->value << endl;
        current = current->next;
    }
}




