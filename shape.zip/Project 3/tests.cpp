/// @file tests.cpp
/// @author Muhammed Arabi
/// @date October 2, 2023
/// @brief Provided testing file to implement Catch 1.x framework tests. 
///   The example below uses the Catch testing framework version that uses
///   a single .hpp file. Initial file authored by:
///   Adam T Koehler, PhD - University of Illinois Chicago

// The tutorial for Catch 1.x can be found at:
// https://github.com/catchorg/Catch2/blob/Catch1.x/docs/tutorial.md

// This tells Catch to provide a main() - do not remove
#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "shape.h"
#include "canvaslist.h"


using namespace std;

TEST_CASE("(0) no tests") 
{
  //
  // done
  // 
}
//test case batch 1: shape class getter and setter.
TEST_CASE("test case 1: shape class - getters and setters") {
  Shape shape;
  Shape newShape(2, 3);

  REQUIRE(shape.getX() == 0);
  REQUIRE(shape.getY() == 0);
    
  REQUIRE(newShape.getX() == 2);
  REQUIRE(newShape.getY() == 3);
    
  shape.setX(5);
  shape.setY(7);
  REQUIRE(shape.getX() == 5);
  REQUIRE(shape.getY() == 7);
}

//test case 2: output of printshape():
TEST_CASE("test case 2 shape class output") {
  Shape shape(2, 3);
  REQUIRE(shape.printShape() == "It's a Shape at x: 2, y: 3"); 
}
//test case batch 3: insertion of shapes into canvaslist:
TEST_CASE("CanvasList test case 1: inserting shapes into CanvasList") {
  CanvasList canvas;
  Shape shape1(1, 2);
  Shape shape2(3, 4);
  Shape shape3(5, 6);
    
  canvas.push_back(&shape1);
  canvas.push_back(&shape2);
  canvas.push_front(&shape3);
    
  REQUIRE(canvas.size() == 3);
  REQUIRE(canvas.shapeAt(0)->getX() == 5);
  REQUIRE(canvas.shapeAt(1)->getX() == 1);
  REQUIRE(canvas.shapeAt(2)->getX() == 3);
}
//test case batch 4: tests removeAt(), push_back(), pop_back(), and shapeAt()
TEST_CASE("CanvasList test case 2: removing shapes from CanvasList") {
  CanvasList canvas;
  Shape shape1(1, 2);
  Shape shape2(3, 4);
    
  canvas.push_back(&shape1);
  canvas.push_back(&shape2);
    
  canvas.removeAt(0);
  REQUIRE(canvas.size() == 1);
  REQUIRE(canvas.shapeAt(0)->getX() == 3);
    
  canvas.pop_back();
  REQUIRE(canvas.size() == 0);
  REQUIRE(canvas.isempty() == true);
}
//test case batch 5: tests copy constructor and =operator
TEST_CASE("CanvasList test case 3: copy constructor and assignment operator") {
  CanvasList canvas1;
  Shape shape1(1, 2);
  Shape shape2(3, 4);
    
  canvas1.push_back(&shape1);
  canvas1.push_back(&shape2);
    
  CanvasList canvas2 = canvas1; 
    
  REQUIRE(canvas2.size() == 2);
  REQUIRE(canvas2.shapeAt(0)->getX() == 1);
  REQUIRE(canvas2.shapeAt(1)->getY() == 4);
    
  CanvasList canvas3;
  Shape shape3(5, 6);
  canvas3.push_back(&shape3);
    
  canvas3 = canvas1; 
    
  REQUIRE(canvas3.size() == 2);
  REQUIRE(canvas3.shapeAt(0)->getY() == 2);
  REQUIRE(canvas3.shapeAt(1)->getX() == 3);
}
