//file name: Shape.cpp
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 3: Shape list project
//this file implements the Shape class intialized in shape.h, which gets and assigns values for the sizes of
// 3 different shapes and then returns a string explaining the characteristics of the shape.

#include "shape.h"
#include "catch.hpp"
 
// Shape Class:

//defualt contructor
Shape::Shape(){
    x =0;
    y =0;
}
//intializes x and y to correct values
Shape::Shape(int a, int b){
    x = a;
    y = b;
}
//destructor
Shape::~Shape() {
    
}
//creates new shape with same x and y values
Shape* Shape::copy() {
    return new Shape(x, y);
}
//getter: gets x value
int Shape::getX() const {
    return x;
}
//getter: gets y value
int Shape::getY() const {
    return y;
}
//setter: sets x equal to the correct value
void Shape::setX(int newX) {
    x = newX;
}
//setter: sets y equal to the correct value
void Shape::setY(int newY) {
    y = newY;
}
//returns string explaining shapes x and y coordinates
string Shape::printShape() const {
    return "It's a Shape at x: " + to_string(x) + ", y: " + to_string(y);
}


//Rectangle class

//default constructor, sets width and height to zero
Rect::Rect(){
    width = 0;
    height =0;
}

//initializes width and height to declared values
Rect::Rect(int w, int h){
    width = w;
    height = h;
}
//assigns values below to Shape class constructor
Rect::Rect(int x, int y, int w, int h) : Shape(x, y), width(w), height(h) {

}

//destructor
Rect::~Rect() {

}
//creates new copy of Rectangle
Rect* Rect::copy() {
    return new Rect(x, y, width, height);
}
//getter: gets width value
int Rect::getWidth() const {
    return width;
}
//getter: gets height value
int Rect::getHeight() const {
    return height;
}
//setter: sets width equal to the correct value
void Rect::setWidth(int newWidth) {
    width = newWidth;
}
//setter: sets height equal to the correct value
void Rect::setHeight(int newHeight) {
    height = newHeight;
}
//returns string explaining width and height of rectangle
string Rect::printShape() const {
    return "It's a Rectangle at x: " + to_string(x) + ", y: " + to_string(y) +
           " with width: " + to_string(width) + " and height: " + to_string(height);
}

// Circle Class 

//default constructor, sets radius to zero
Circle::Circle(){
    radius = 0;
}
//initializes radius to declared values
Circle::Circle(int r){
    radius = r;
}
//assigns values below to Circle class constructor
Circle::Circle(int x, int y, int r) : Shape(x, y), radius(r) {

}
//destructor
Circle::~Circle() {
    
}
//creates new copy of Circl
Circle* Circle::copy() {
    return new Circle(x, y, radius);
}
//Getter: gets radius value:
int Circle::getRadius() const {
    return radius;
}
//Setter: sets radius value equal to newRadius
void Circle::setRadius(int newRadius) {
    radius = newRadius;
}
//returns string explaining x, y and radius of Circle
string Circle::printShape() const {
    return "It's a Circle at x: " + to_string(x) + ", y: " + to_string(y) +
           ", radius: " + to_string(radius);
}

// RightTriangle Class 

//default constructor, sets base and height to zero
RightTriangle::RightTriangle(){
    base =0;
    height =0;
}
//initializes base and height to declared values
RightTriangle::RightTriangle(int b, int h){
    base = b;
    height = h;
}
//assigns values below to Right triangele class constructor

RightTriangle::RightTriangle(int x, int y, int b, int h) : Shape(x, y), base(b), height(h) {

}

//destructor
RightTriangle::~RightTriangle() {

}
//creates new copy of Right triangle
RightTriangle* RightTriangle::copy() {
    return new RightTriangle(x, y, base, height);
}
//getter: gets base value
int RightTriangle::getBase() const {
    return base;
}
//getter: gets height value
int RightTriangle::getHeight() const {
    return height;
}
//Setter: sets base value equal to newbase
void RightTriangle::setBase(int newBase) {
    base = newBase;
}
//setter: sets height value equal to newHeight
void RightTriangle::setHeight(int newHeight) {
    height = newHeight;
}
//returns string explaining x, y, base and height of right triangle
string RightTriangle::printShape() const {
    return "It's a Right Triangle at x: " + to_string(x) + ", y: " + to_string(y) +
           " with base: " + to_string(base) + " and height: " + to_string(height);
}
