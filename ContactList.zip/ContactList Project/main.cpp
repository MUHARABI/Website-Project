 #include <iostream>
 #include <fstream>
 #include <vector>
 #include <string>
 #include <algorithm>
 #include "ContactList.h"

using namespace std;
//Project 4 Part 2, user interface.
//Programmer: Muhammed Arabi
//date: 4/1/23

string displayFunction(){ //main menu printed
   cout << "********************************************"<<'\n'  << "Main Menu" << '\n' << '\n' << "Enter the letter for the desired menu option:" << '\n' << "   C - Get count" << '\n' << "   L - Load contacts from file"<< '\n' << "   S - Search contacts" << '\n' << "   P - Print contacts" << '\n' << "   X - Exit" << endl;
  string choice;
  cin >> choice;
  return choice;
}


// printing the search results
void printSearchResult(vector<int> positions, ContactList& contactList){
  int tmp = positions.size();
  if(tmp == 1){
    cout << "\nFound " << tmp << " result\n";
    for(int i =0; i < tmp; i++){
      int index = positions[i];
      cout << (i+1) << ". " << contactList.getContact(index)->getName() << endl;
    }
  }
  else if(tmp > 1){
    cout << "\nFound " << tmp << " results\n";
    for(int i =0; i < tmp; i++){
      int index = positions[i];
      cout << (i+1) << ". " << contactList.getContact(index)->getName() << endl;
    }
  }
  else{
      cout << "\nNo results found\n";
    }
}
//function to check if its int 
bool isNumber(const string& s)
{
    for (char const &ch : s) {
        if (std::isdigit(ch) == 0) 
            return false;
    }
    return true;
 }




// printing the print menu
void printContactsMenu(ContactList& contactList, vector<int> positions){ 
  cout << "Enter an option:" << endl;
    cout << "   P - Print contacts" << endl;
    cout << "   or a Contact number to view/edit" << endl;
    cout << "   R - Return to main menu " << endl;
    cout << endl;
  while(true){
    string choice;
    cin >> choice;
    if (choice == "P"){
      contactList.printContacts(positions);
      break;
    }
    else if (choice == "R"){
      break;
    }
    else if (isNumber(choice)) {
      int index = stoi(choice)-1;
      if (index >= 0 && index < positions.size()){
        cout << endl;
        cout << contactList.getContact(positions[index])->getAsString() << endl;
        cout << endl;
        cout << "Enter an option for contact:" << endl;
        cout << "   A - Edit address" << endl;
        cout << "   B - Edit date of birth" << endl;
        cout << "   E - Edit email address" << endl;
        cout << "   N - Edit name" << endl;
        cout << "   P - Edit phone numbers" << endl;
        cout << "   R - Return to main menu" << endl;
        cout << "   D - Delete" << endl;
        string option;
        cin >> option;
        //edits address
        if(option == "A"){ 
          
        }
        //edits date of birth
        else if(option == "B"){ 
          
        }
        // edits email address
        else if(option == "E"){ 
          cout << "Current email:\n" << contactList.getContact(positions[index])->getEmail() << endl;
          cout << endl;
          cout << "Enter new email or C to cancel:" << endl;
          cout << endl;
          string subChoice;
          cin >> subChoice;
          if(subChoice == "C"){
            break;
          }else{
            
          contactList.getContact(positions[index])->setEmail(subChoice);
          cout << "Email updated:\n" << subChoice << endl;
          cout << endl;
          
          }
        }
        //edits name
        else if(option == "N"){
          
        }
        //edits phone number info
        else if(option == "P"){
          vector<string> phoneNumbers = contactList.getContact(positions[index])->getPhoneNumbers(); 
          if(phoneNumbers.size() > 1){
            cout << "Found " << phoneNumbers.size() << " phone numbers" << endl;
          }
          else if(phoneNumbers.size() == 1){
            cout << "Found " << phoneNumbers.size() << " phone number" << endl;
          }
          for (int i = 0; i < phoneNumbers.size(); i++) {
        cout << i+1 << ". " << phoneNumbers[i] << endl;
          }
          cout << "Enter an option:" << endl;
          cout << "   A - Add a phone number" << endl;
          cout << "   R - Return to main menu" << endl;
          cout << "   or list number to delete" << endl;
          cout << endl;
          string subChoice;
          cin >> subChoice;
          if(subChoice == "A"){
            cout << "Enter the letter for the phone number type:" << endl;
            cout << "C(ell), W(ork) or H(ome)" << endl;
            char ptype;
            cin >> ptype;
            cout << "Enter the phone number:" << endl;
            string number;
            cin >> number;
            cout << contactList.getContact(positions[index])->addPhone(ptype, number) << endl;
            cout << endl;
            cout << endl;
            
          }
          else if(subChoice == "R"){ 
            break;
          }
          else if(isNumber(subChoice)){
            cout << "Are you sure you want to delete phone: " << phoneNumbers[stoi(subChoice)-1] << "?" << endl;
            cout << "Enter 'Y' to confirm." << endl;
            string confirmation;
            cin >> confirmation;
            if(confirmation == "Y"){
             
              cout << contactList.getContact(positions[index])->deletePhone(stoi(subChoice)-1) << endl;
              
            
            cout << endl;
            cout << endl;
            }
          }
        }
        //returns to main menu
        else if(option == "R"){
          break; 
        }
        //deletes contacts
        else if(option == "D"){
          cout << "Are you sure you want to delete contact " << contactList.getContact(positions[index])->getName() << "?" << endl;
          cout << "Enter 'Y' to confirm." << endl;
          string subChoice;
          cin >> subChoice;
          if(subChoice == "Y"){
            cout << contactList.deleteContact(positions[index]) << endl;
            cout << endl;
          }
        }
        break; //returns to main menu
        
      }
      
    }
    // error check
    else{
      cout << "Invalid input" << endl;
    }
    
  }
  
  
}

// main
int main(){
  ContactList c;
  
  string choice;
  choice = displayFunction();
  while(choice != "X"){
    //gets contact count
    if (choice == "C"){
      cout << "There are " << c.getCount() << " contacts" << endl;
      
    }
    //loads contacts
    if (choice  == "L"){
      string filename;
      cout << "Enter a filename" << endl;
      cin >> filename;
      cout << c.loadContactsFromFile (filename) << endl;
      cout << endl;
      cout << endl;
      
    }
    //searches based on terms
    if(choice == "S"){
      cout << "Enter a search term" << endl;
      string search;
      cin >> search;
      vector<int> positions = c.findContactsByName(search);      
      printSearchResult(positions, c);
      cout << endl;
      printContactsMenu(c, positions);
    }
    
    
    
    
    choice = displayFunction();
  }
  
}