//file name: search.h
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 2: Search Project
/*This file contains the function for the search project which are called in main
and takes in the filename entered, and the search query and displays the various websites and links
based on the search query
*/


#pragma once

#include <iostream>
#include <string>
#include <set>
#include <map>
#include <sstream>
#include <fstream>
#include <algorithm>
using namespace std;


//takes in string and then cleans by checking if string contains at least 1 letter 
//and then deleting any trailing or leading whitespace
string cleanToken(string s) {
    string cleanedToken = "";
    bool insideToken = false;
    bool foundLetter = false;
    for (char c : s) {
        //checks for anything other than digit or letter and if its inside the token or 
        //if its in the begining or end of the token
        if(ispunct(c) || isspace(c)){
            if(insideToken){
                cleanedToken+=c;
            }
            else{
                continue;
            }
        }
        else{
            cleanedToken += tolower(c);
            insideToken = true;
            if (isalpha(c)){
                foundLetter = true;
            }
        } 
    }
    //gets rid of  whitespace or punct at the end via pop() function
    while (!cleanedToken.empty() && (ispunct(cleanedToken.back()) || isspace(cleanedToken.back()))) {
        cleanedToken.pop_back();
    }
    //if token doesnt have a letter, it returns an empty string.
    if(!foundLetter){
        cleanedToken = "";
    }
    return cleanedToken;
}

//searches for the word in the textfile links and inserts the selected links 
//into the set tokens and that gets returned
set<string> gatherTokens(string text) {
    set<string> tokens;
    stringstream textFile(text);
    string word;
    //searches textfile for the word 
    while (textFile >> word) {
        string cleanedToken = cleanToken(word);
        if (!cleanedToken.empty()) {
            tokens.insert(cleanedToken);
        }
    }
    return tokens;  
}

// The function builds an index of documents from the file. 
// It reads the file line by line, where each document is represented by two lines:
// The first line contains the document's URL link.
// The second line contains the document's text.
// the map has a set of links that correspond with what the gathertokens function returns.
// The function returns the total number of documents indexed.
int buildIndex(string filename, map<string, set<string>>& index) {

    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: Unable to open file " << filename << endl;
        return 0; 
    }

    int documentCount = 0;
    string line;
    string currentURL = "";
    string currentBody = "";
    //loops through entire file line by line
    while (getline(file, line)) {
        if (currentURL.empty()) {
            currentURL = line;
        } else {
            currentBody = line;
            //calls gather tokens with line to grab link to index into count
            set<string> tokens = gatherTokens(currentBody);
            
            for (const string& token : tokens) {
                index[token].insert(currentURL);
            }
            currentURL = "";
            currentBody = "";
            documentCount++;
        }
    }
    file.close();
    return documentCount;
  
    return 0;
}

// The function takes a search sentence and a map of indexed strings.
// It performs a search on the indexed data based on the search sentence, which includes intersection, difference, and union operations.
// The function returns a set of strings that match the search.
set<string> findQueryMatches(map<string, set<string>>& index, string sentence) {
    set<string> result;
    string search;
    stringstream stream(sentence);
    while(stream >> search){
        //intersection
        if(search[0]== '+'){
            set<string> intersection;
            search = cleanToken(search);
            set_intersection(result.begin(), result.end(), index.at(search).begin(), index.at(search).end(), inserter(intersection, intersection.begin()));
            result = intersection;
        }
        //difference
        else if(search[0]== '-'){
            set<string> difference;
            search = cleanToken(search);
            set_difference(result.begin(), result.end(), index.at(search).begin(), index.at(search).end(), inserter(difference, difference.begin()));
            result = difference;
        }
        //union
        else if(isalpha(search[0])){
            search = cleanToken(search);
            for(auto& link: index.at(search)){
                result.insert(link);
            }
        }
    }
    
    return result;  
}

// This function builds an index of documents from a given file, where each document is represented by a URL and body text.
// The user will enter search sentences containing one or more words. 
// The function then uses the build Index function to find and display documents that match the search sentence.
// The search can include operations like + (intersection) and - (difference) to refine the results.
void searchEngine(string filename) {
    map<string, set<string>> index;

    cout << "Stand by while building index..." << endl;
    //calls index function and gets the number
    int Count = buildIndex(filename, index);
    cout << "Indexed " << Count << " pages containing " << index.size() << " unique terms" << endl;

    string search;
    //while still searching:
    while (true) {
        cout << "\nEnter query sentence (press enter to quit): ";
        getline(cin, search);

        if (search.empty()) {
            cout << "Thank you for searching!" << endl;
            break; //ends search loop
        }

        set<string> matches = findQueryMatches(index, search);
        cout << "Found " << matches.size() << " matching pages" << endl;
        //displays links
        for (const string& link : matches) {
            cout << link << endl;
        }
    }
}


