//file name: Main.cpp
//Name: Muhammed Arabi
//net ID: marab2
//CS 251 12:00 Section
//Project 2: Search Project
// this is the main file where the function is called from the search.h file. this file takes in the 
// file name input and calls the search engine function to display the correpsonding links. 
// this file also custom test cases to test each function and make sure they work correctly.

#include "search.h"
using namespace std;

//test case for cleantoken function:
bool testCleanToken() {
    
    int pass = 0;
    int fail = 0;
    
    string ans = "test";
    ans == cleanToken(".test") ? ++pass : ++fail;
    ans == cleanToken("...~test") ? ++pass : ++fail;
    ans = "324check";
    ans == cleanToken("324check") ? ++pass : ++fail;
    ans = "test";
    ans == cleanToken("  test  ") ? ++pass : ++fail;
    

    if(fail == 0){
        return true; 
    }
    else{
        return false;
        
    }

    
}
//test case for gather tokens function
bool testGatherTokens() {
    string text = "This checks to make sure text was gathered";
    set<string> tokens = gatherTokens(text);
    
    int pass = 0; 
    int fail = 0;
    
    tokens.count("this") == 1 ? ++pass : ++fail;
    tokens.count("to") == 1 ? ++pass : ++fail;
    tokens.count("gathered") == 1 ? ++pass : ++fail;
    tokens.count("text") == 1 ? ++pass : ++fail;
    tokens.count("was") == 1 ? ++pass : ++fail;
    
    if(fail == 0){
        return true; 
    }
    else{
        return false;
        
    }
}

bool testBuildIndex() {
    // Creates a temporary file with sample data
    ofstream tempFile("temp.txt");
    tempFile << "www.Test.com" << endl;
    tempFile << "this tests the index function." << endl;
    tempFile.close();

    map<string, set<string>> index;
    int documentCount = buildIndex("temp.txt", index);
    
    int pass = 0; 
    int fail = 0;

    documentCount == 1 ? ++pass : ++fail;
    index.count("this") == 1 ? ++pass : ++fail; 
    index.count("tests") == 1 ? ++pass : ++fail;
    index.count("the") == 1 ? ++pass : ++fail;
    index.count("index") == 1 ? ++pass : ++fail;
    index.count("function") == 1 ? ++pass : ++fail;
    
    if(fail == 0){
        return true; 
    }
    else{
        return false;
        
    }
}

bool testFindQueryMatches() {
    map<string, set<string>> index;
    set<string> result;

    // Populate the index with sample data into temp.txt
    index["this"].insert("temp.txt");
    index["tests"].insert("temp.txt");
    index["the"].insert("temp.txt");
    index["find"].insert("temp.txt");
    index["query"].insert("temp.txt");
    index["function"].insert("temp.txt");
   
    int pass = 0; 
    int fail = 0;
    result = findQueryMatches(index, "this");
    result.count("temp.txt") == 1 ? ++pass : ++fail;
    result = findQueryMatches(index, "the");
    result.count("temp.txt") == 1 ? ++pass : ++fail;
    result = findQueryMatches(index, "function~");
    result.count("temp.txt") == 1 ? ++pass : ++fail;
    result = findQueryMatches(index, "Query");
    result.count("temp.txt") == 1 ? ++pass : ++fail;
    
    
    if(fail == 0){
        return true; 
    }
    else{
        return false;
        
    }
}
void printResult(){
    if (testCleanToken()) {
        cout << "CleanToken function passed all tests." << endl;
    } else {
        cout << "CleanToken function did not pass all tests." << endl;
    }

    if (testGatherTokens()) {
        cout << "GatherTokens function passed all tests." << endl;
    } else {
        cout << "GatherTokens function did not pass all tests." << endl;
    }

    if (testBuildIndex()) {
        cout << "BuildIndex function passed all tests." << endl;
    } else {
        cout << "BuildIndex function did not pass all tests." << endl;
    }

    if (testFindQueryMatches()) {
        cout << "FindQueryMatches function passed all tests." << endl;
    } else {
        cout << "FindQueryMatches function did not pass all tests." << endl;
    }
}

int main() {
    
    // Use this function to call and test the functions you write inside of
    // search.h.  If you do not call the functions here, nothing will run.

    string filename;
    printResult();
    getline(cin, filename);
    searchEngine(filename);
    
    

    return 0;
}


