// testing.cpp <Starter Code>
// <Your name>
//
// Adam T Koehler, PhD
// University of Illinois Chicago
// CS 251, Fall 2023
//
// Project Original Variartion By:
// Joe Hummel, PhD
// University of Illinois at Chicago
//
// This file is used for testing graph.h.  We encourage you to use Google's
// test framework for this project, but it is not required (because we will
// not be grading the tests file).  
//

#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <string>
#include <fstream>

#include "graph.h"

using namespace std;


//
// buildGraph:
//
// Inputs the graph vertices and edges from the given file, building
// the graph g.  File format:
//   vertex 
//   vertex
//   ...
//   #
//   src dest weight
//   src dest weight
//   ... 
//   #
//
void buildGraph(string filename, graph<long long, int>& G)
{
  ifstream file(filename);
  long long v;

  if (!file.good())
  {
    cout << endl;
    cout << "**Error: unable to open input file '" << filename << "'." << endl;
    cout << endl;
    return;
  }

  //
  // Input vertices as single integers:  1 2 3 ... #
  //
  file >> v;

  while (v != -1) // Assuming -1 is the sentinel value for the end of vertices
  {
    if (!G.addVertex(v))
      cout << "**Error: unable to add vertex '" << v << "', why not?" << endl;

    file >> v;
  }

  //
  // Now input edges:  Src Dest Weight ... #
  //
  long long src, dest;
  int weight;

  file >> src;

  while (src != -1) // Assuming -1 is the sentinel value for the end of edges
  {
    file >> dest;
    file >> weight;

    if (!G.addEdge(src, dest, weight))
      cout << "**Error: unable to add edge (" << src << "," << dest << "," << weight << "), why not?" << endl;

    file >> src;
  }
}

//
// outputGraph:
//
// Outputs graph g to the console.
//
void outputGraph(graph<long long, int>& G)
{
  vector<long long> vertices = G.getVertices();

  cout << "**Vertices: ";

  for (long long v : vertices)
  {
    cout << v << " ";
  }

  cout << endl;

  cout << "**Edges: ";

  for (long long v : vertices)
  {
    set<long long> neighbors = G.neighbors(v);

    for (long long n : neighbors)
    {
      int weight;

      if (G.getWeight(v, n, weight))
      {
        cout << "(" << v << "," << n << "," << weight << ") ";
      }
      else
      {
        cout << "(" << v << "," << n << "," << "???" << ") ";
      }
    }
  }

  cout << endl;
}

int main()
{
  graph<long long, int> G(26); // Use long long for vertices and int for weights
  long long startV;
  string filename;
  cout << "Enter filename containing graph data> ";
  cin >> filename;
  cout << endl;

  // Let's input the graph, and then output to see what we have:
  buildGraph(filename, G);

  // Output the graph
  outputGraph(G);

  // Ask the user for the starting vertex
  cout << "Enter the starting vertex for Dijkstra's algorithm> ";
  cin >> startV;

  // Check if the starting vertex exists in the graph
  if (G.addVertex(startV)) {
    // Run Dijkstra's algorithm
    map<long long, int> distances;
    map<long long, long long> predecessors;
    G.Dijkstra(startV, distances, predecessors);

    // Output the distances and predecessors
    cout << "Dijkstra's Algorithm Results:" << endl;
    for (const auto& vertex : G.getVertices()) {
      cout << "Distance from " << startV << " to " << vertex << ": " << distances[vertex] << " | ";
      cout << "Predecessor: " << predecessors[vertex] << endl;
    }
  } else {
    cout << "Starting vertex not found in the graph." << endl;
  }

  // done:
  return 0;
}