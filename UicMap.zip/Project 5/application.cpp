// application.cpp <Starter Code>
// Muhammed Arabi
//
//
// Adam T Koehler, PhD
// University of Illinois Chicago
// CS 251, Fall 2023
//
// Project Original Variartion By:
// Joe Hummel, PhD
// University of Illinois at Chicago
//
// 
// References:
// TinyXML: https://github.com/leethomason/tinyxml2
// OpenStreetMap: https://www.openstreetmap.org
// OpenStreetMap docs:
//   https://wiki.openstreetmap.org/wiki/Main_Page
//   https://wiki.openstreetmap.org/wiki/Map_Features
//   https://wiki.openstreetmap.org/wiki/Node
//   https://wiki.openstreetmap.org/wiki/Way
//   https://wiki.openstreetmap.org/wiki/Relation
//

#include <iostream>
#include <iomanip>  /*setprecision*/
#include <string>
#include <vector>
#include <map>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <unordered_map>

#include "tinyxml2.h"
#include "dist.h"
#include "graph.h"
#include "osm.h"


using namespace std;
using namespace tinyxml2;

const double INF = std::numeric_limits<double>::max();

//searches for a building by abbreviation name
BuildingInfo findBuilding(const string& name, const vector<BuildingInfo>& Locations) {
    for (const auto& place : Locations) {
        if (place.Abbrev == name) {
            return place;
        }
    }
    return BuildingInfo{}; 
}

//Function to search for a building by namw
BuildingInfo findBuildingName(const string& name, const vector<BuildingInfo>& Locations) {
    for (const auto& place : Locations) {
        if (place.Fullname.find(name) != string::npos) {
            return place;
        }
    }
    return BuildingInfo{};
}

//Dijkstra's algorithm
template<typename VertexT, typename WeightT>
void Dijkstra(const graph<VertexT, WeightT>& G, VertexT begin, unordered_map<VertexT, WeightT>& distance, unordered_map<VertexT, VertexT>& predecessor) {
    set<pair<WeightT, VertexT>> pq;
    distance.clear();
    predecessor.clear();

    // Initialize distance and previous
    for (const VertexT& v : G.getVertices()) {
        distance[v] = INF;
        predecessor[v] = VertexT();
    }

    distance[begin] = 0;
    pq.insert(make_pair(distance[begin], begin));
    //loops through pq
    while (!pq.empty()) {
        VertexT curr = pq.begin()->second;
        pq.erase(pq.begin());

        for (const VertexT& neighbor : G.neighbors(curr)) {
            WeightT Weight;
            G.getWeight(curr, neighbor, Weight);

            WeightT tempDistance = distance[curr] + Weight;
            if (tempDistance < distance[neighbor]) {
                pq.erase(make_pair(distance[neighbor], neighbor));
                distance[neighbor] = tempDistance;
                predecessor[neighbor] = curr;
                pq.insert(make_pair(distance[neighbor], neighbor));
            }
        }
    }
}


//finds the shortest path from the previous map
vector<long long> shortestPath(unordered_map<long long, long long>& previous, long long startNode, long long endNode) {
    vector<long long> path;
    long long currentNode = endNode;

    while (currentNode != startNode) {
        if (previous.find(currentNode) == previous.end()) {
            return {};
        }
        path.push_back(currentNode);
        currentNode = previous[currentNode];
    }
    path.push_back(startNode);
    reverse(path.begin(), path.end());
    return path;
}
//Creates a graph by adding a vertex and edges using Nodes and Footways
void buildGraph(graph<long long, double>& G, const map<long long, Coordinates>& Nodes, const vector<FootwayInfo>& Footways) {
    for (const auto& n : Nodes) {
        G.addVertex(n.first);
    }

    for (const auto& f : Footways) {
        for (size_t i = 0; i < f.Nodes.size() - 1; ++i) {
            long long node1ID = f.Nodes[i];
            long long node2ID = f.Nodes[i + 1];
            Coordinates node1Coords = Nodes.at(node1ID);
            Coordinates node2Coords = Nodes.at(node2ID);

            // Calculate the distance between the two nodes
            double distance = distBetween2Points(node1Coords.Lat, node1Coords.Lon, node2Coords.Lat, node2Coords.Lon);

            
            G.addEdge(node1ID, node2ID, distance);
            G.addEdge(node2ID, node1ID, distance); 
        }
    }
}


//finds closest building by calling distBetween2points 
BuildingInfo closestBuilding(const Coordinates& coords, const vector<BuildingInfo>& buildings) {
    double minDistance = INF;
    BuildingInfo nearestBuilding;

    for (const auto& building : buildings) {
        double distance = distBetween2Points(coords.Lat, coords.Lon, building.Coords.Lat, building.Coords.Lon);
        if (distance < minDistance) {
            minDistance = distance;
            nearestBuilding = building;
        }
    }

    return nearestBuilding;
}


//finds closest node by calling distBetween2points 
long long closestNode(const Coordinates& buildingCoords, const vector<FootwayInfo>& Footways, const map<long long, Coordinates>& Nodes) {
    long long Id = -1;
    double closestNodeDistance = INF;

    //loops through footways vector
    for (const auto& footway : Footways) {
        
        for (const long long& nodeID : footway.Nodes) {
            const Coordinates& nodeLocation = Nodes.at(nodeID); 
            //calls function to find dist bwteen two points based on coordinates 
            double dist = distBetween2Points(buildingCoords.Lat, buildingCoords.Lon, nodeLocation.Lat, nodeLocation.Lon);

            
            if (dist < closestNodeDistance) {
                closestNodeDistance = dist;
                Id = nodeID;
            }
        }
    }

    return Id; 
}
//prints building coordinates and name
void printBuildingInfo(const BuildingInfo& building) {
    cout << " " << building.Fullname << endl;
    cout << " (" << building.Coords.Lat << ", " << building.Coords.Lon << ")" << endl;
}



//prints path information
void printPathInfo(const vector<long long>& path) {
    cout << "Path: ";
    for (auto node : path) {
        cout << node << "->";
    }
    cout << endl;
}

//prints distance information
void printDistanceInfo(double distance) {
    cout << distance << " miles" << endl;
}

//prints information about the nearest node
void printClosestInfo(long long nodeId, const Coordinates& coords, const map<long long, Coordinates>& Nodes) {
    cout << " " << nodeId << endl;

    // Check if the node ID exists in the Nodes map
    if (Nodes.find(nodeId) != Nodes.end()) {
        Coordinates nodeCoords = Nodes.at(nodeId);
        cout << " (" << nodeCoords.Lat << ", " << nodeCoords.Lon << ")" << endl;
    } else {
        cout << " Node coordinates not found." << endl;
    }
}
//Application function
void application(map<long long, Coordinates>& Nodes, vector<FootwayInfo>& Footways, vector<BuildingInfo>& Buildings, graph<long long, double>& G) {
    string person1Building, person2Building;

    cout << endl;
    cout << "Enter person 1's building (partial name or abbreviation), or #> ";
    getline(cin, person1Building);
    //continues untill # is entered then program is ended:
    while (person1Building != "#") {
        cout << "Enter person 2's building (partial name or abbreviation)> ";
        getline(cin, person2Building);

        //initializes first building
        BuildingInfo firstBuilding = findBuilding(person1Building, Buildings);
        if (firstBuilding.Fullname.empty()) {
            //calls function to find building based on name entered
            firstBuilding = findBuildingName(person1Building, Buildings);
        }

        if (firstBuilding.Fullname.empty()) {
            cout << "Person 1's building not found" << endl;
            cout << "Enter person 1's building (partial name or abbreviation), or #> ";
            getline(cin, person1Building);
            continue;
        }
        //intilializes second building
        BuildingInfo secondBuilding = findBuilding(person2Building, Buildings);
        if (secondBuilding.Fullname.empty()) {
            //calls function to find secodn buiiding name based on entered name:
            secondBuilding = findBuildingName(person2Building, Buildings);
        }
        //checks to makes sure building name is valid and available
        if (secondBuilding.Fullname.empty()) {
            cout << "Person 2's building not found" << endl;
            cout << "Enter person 1's building (partial name or abbreviation), or #> ";
            getline(cin, person1Building);
            continue;
        }

        //find the nearest nodes for each building b calling closestNode function:
        long long closest1 = closestNode(firstBuilding.Coords, Footways, Nodes);
        long long closest2 = closestNode(secondBuilding.Coords, Footways, Nodes);

        //gets coordinates (latitude and longitude) for each building
        double latitude1 = firstBuilding.Coords.Lat;
        double longitude1 = firstBuilding.Coords.Lon;
        double latitude2 = secondBuilding.Coords.Lat;
        double longitude2 = secondBuilding.Coords.Lon;

        //takes those coordinates and calls centerBetween2points function to get center coordinates
        Coordinates centerCoords = centerBetween2Points(latitude1, longitude1, latitude2, longitude2);
        //uses center coordinates to find closes building by calling function and sending centerCoords as parameter alongside buildings
        BuildingInfo closeBuilding = closestBuilding(centerCoords, Buildings);

        //finds closest nodes using footways, nodes ,and coordinates
        long long nearestNode = closestNode(closeBuilding.Coords, Footways, Nodes);

        //intialize two distance maps, and the two predecessor maps
        unordered_map<long long, double> d1;
        unordered_map<long long, double> d2;
        unordered_map<long long, long long> pred1;
        unordered_map<long long, long long> pred2;

        //use Dijkstra algorithim to use distance and predecessors to update distance and predecessor maps
        Dijkstra(G, closest1, d1, pred1);
        Dijkstra(G, closest2, d2, pred2);

        //calls function to find shortest path for each building
        vector<long long> path1 = shortestPath(pred1, closest1, nearestNode);
        vector<long long> path2 = shortestPath(pred2, closest2, nearestNode);
         
        //bool variables to make sure path is valid:
        bool Validpath1 = !path1.empty();
        bool Validpath2 = !path2.empty();

        //calls function to print the first building info
        cout << "Person 1's point:" << endl;
        printBuildingInfo(firstBuilding);
 
        //calls function to print the second buildings info
        cout << "Person 2's point:" << endl;
        printBuildingInfo(secondBuilding);

        //calls function to print destination info
        cout << "Destination Building:" << endl;
        printBuildingInfo(closeBuilding);

        
        //calls function prints closest node info for P1
        cout << "Nearest P1 node:" << endl;
        printClosestInfo(closest1, firstBuilding.Coords, Nodes);
        //calls function prints closest node info for P2
        cout << "Nearest P2 node:" << endl;
        printClosestInfo(closest2, secondBuilding.Coords, Nodes);
        //calls function prints closest node info for destination
        cout << "Nearest destination node:" << endl;
        printClosestInfo(nearestNode, closeBuilding.Coords, Nodes);
        cout << endl;
        
        //checks using valid bool variables to make sure path is valid, then prints path info
        if (Validpath1 && Validpath2) {
            cout << "Person 1's distance to dest: ";
            printDistanceInfo(d1[nearestNode]);
            printPathInfo(path1);
            cout << "Person 2's distance to dest: ";
            printDistanceInfo(d2[nearestNode]);
            printPathInfo(path2);
        } else { //else its unreachable
          cout << "Sorry, destination unreachable." << endl;
        }

        cout << endl;
        cout << "Enter person 1's building (partial name or abbreviation), or #> " << endl;
        getline(cin, person1Building);
    }
}

//main
int main() {
  graph<long long, double> G;

  map<long long, Coordinates> Nodes;
  vector<FootwayInfo> Footways;
  vector<BuildingInfo> Buildings;
  XMLDocument xmldoc;

  cout << "** Navigating UIC open street map **" << endl;
  cout << endl;
  cout << std::setprecision(8);

  string def_filename = "map.osm";
  string filename;

  cout << "Enter map filename> ";
  getline(cin, filename);

  if (filename == "") {
    filename = def_filename;
  }

  if (!LoadOpenStreetMap(filename, xmldoc)) {
    cout << "**Error: unable to load open street map." << endl;
    cout << endl;
    return 0;
  }

  int nodeCount = ReadMapNodes(xmldoc, Nodes);
  int footwayCount = ReadFootways(xmldoc, Footways);
  int buildingCount = ReadUniversityBuildings(xmldoc, Nodes, Buildings);

  assert(nodeCount == (int)Nodes.size());
  assert(footwayCount == (int)Footways.size());
  assert(buildingCount == (int)Buildings.size());

  cout << endl;
  cout << "# of nodes: " << Nodes.size() << endl;
  cout << "# of footways: " << Footways.size() << endl;
  cout << "# of buildings: " << Buildings.size() << endl;

  // Build the graph and output stats
  buildGraph(G, Nodes, Footways);
  cout << "# of vertices: " << G.NumVertices() << endl;
  cout << "# of edges: " << (G.NumEdges()) << endl;
  cout << endl;

  //calls application function
  application(Nodes, Footways, Buildings, G);

  cout << "** Done **" << endl;
  return 0;
}


