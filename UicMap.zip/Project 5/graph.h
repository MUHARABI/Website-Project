// graph.h <Starter Code>
// Muhammed Arabi
//
// Basic graph class using adjacency matrix representation.  Currently
// limited to a graph with at most 100 vertices.
//
//
// Adam T Koehler, PhD
// University of Illinois Chicago
// CS 251, Fall 2023
//
// Project Original Variartion By:
// Joe Hummel, PhD
// University of Illinois at Chicago
//

#pragma once

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

template<typename VertexT, typename WeightT>
class graph {
 private:
  map<VertexT, vector<pair<VertexT, WeightT>>> adjacencyList;

 public:

  //default constructor
  graph(){

  }

  //destructor
  ~graph(){

  }

  //copy constructor
  graph(const graph& other){
    this->adjacencyList = other.adjacencyList;
  }

  // Assignment operator
  graph& operator=(const graph& other){
    if (this != &other) {  // Self-assignment check
      // Clear existing data
      this->adjacencyList.clear();
      // Make a deep copy of the other graph's data
      this->adjacencyList = other.adjacencyList;
    }
    return *this;

  }

  //
  // NumVertices
  //
  // Returns the # of vertices currently in the graph.
  //
  int NumVertices() const {
    return static_cast<int>(this->adjacencyList.size());
  }

  //
  // NumEdges
  //
  // Returns the # of edges currently in the graph.
  //
  int NumEdges() const {
    int count = 0;
    //loops through adjacencylist
    for (const auto& pair : this->adjacencyList) {
      count += pair.second.size();
    }

    return count;
  }

  //
  // addVertex
  //
  // Adds the vertex v to the graph if there's room, and if so
  // returns true.  If the graph is full, or the vertex already
  // exists in the graph, then false is returned.
  //
  bool addVertex(const VertexT& vertex) {
    //if vertex already exists: 
    if (this->adjacencyList.find(vertex) != this->adjacencyList.end()) {
      return false;  
    }

    //Initialize an empty vector for new vertex
    this->adjacencyList[vertex] = {};  
    return true;
  }

  //
  // addEdge
  //
  // Adds the edge (from, to, weight) to the graph, and returns
  // true.  If the vertices do not exist or for some reason the
  // graph is full, false is returned.
  //
  // NOTE: if the edge already exists, the existing edge weight
  // is overwritten with the new edge weight.
  //
  bool addEdge(VertexT from, VertexT to, WeightT weight) {
    auto it_from = this->adjacencyList.find(from);
    auto it_to = this->adjacencyList.find(to);

    if (it_from == this->adjacencyList.end() || it_to == this->adjacencyList.end()) {
        return false;  
    }

    auto& neighbors = it_from->second;
    
    //Search for the edge
    bool edgeExists = false;
    for (auto& edge : neighbors) {
        if (edge.first == to) {
            //Edge exists, update weight
            edge.second = weight;
            edgeExists = true;
            break;
        }
    }

    // If the edge does not exist, add a new edge
    if (!edgeExists) {
      neighbors.emplace_back(to, weight);
    }

    return true;
}

  //
  // getWeight
  //
  // Returns the weight associated with a given edge.  If
  // the edge exists, the weight is returned via the reference
  // parameter and true is returned.  If the edge does not
  // exist, the weight parameter is unchanged and false is
  // returned.
  //
  bool getWeight(VertexT from, VertexT to, WeightT& weight) const {
    auto prev = this->adjacencyList.find(from);

    if (prev == this->adjacencyList.end()) {
        return false;  
    }

    const auto& neighbors = prev->second;

    //Search for the edge
    for (const auto& edge : neighbors) {
        if (edge.first == to) {
            //if Edge found, set the weight and return true
            weight = edge.second;
            return true;
        }
    }

    
    return false;
  }

  //
  // neighbors
  //
  // Returns a set containing the neighbors of v, i.e. all
  // vertices that can be reached from v along one edge.
  // Since a set is returned, the neighbors are returned in
  // sorted order; use foreach to iterate through the set.
  //
  set<VertexT> neighbors(VertexT v) const {
    set<VertexT> S;

    auto it = this->adjacencyList.find(v);
    if (it != this->adjacencyList.end()) {
      const auto& neighbors = it->second;
      for (const auto& neighbor : neighbors) {
        S.insert(neighbor.first);
      }
    }

    return S;
  }

  //
  // getVertices
  //
  // Returns a vector containing all the vertices currently in
  // the graph.
  //
  vector<VertexT> getVertices() const {
    vector<VertexT> vertices;
    //loops through adjacency list
    for (const auto& pair : this->adjacencyList) {
      //adds vertex to vector
      vertices.push_back(pair.first);
    }
    //returns vector of vertices
    return vertices;
  }
  //
  // dump
  //
  // Dumps the internal state of the graph for debugging purposes.
  //
  // Example:
  //    graph<string,int>  G(26);
  //    ...
  //    G.dump(cout);  // dump to console
  //
  void dump(ostream& output) const {
    output << "***************************************************" << endl;
    output << "********************* GRAPH ***********************" << endl;

    output << "**Num vertices: " << this->NumVertices() << endl;
    output << "**Num edges: " << this->NumEdges() << endl;

    output << endl;
    output << "**Vertices:" << endl;
    for (const auto& pair : this->adjacencyList) {
      output << " " << pair.first << endl;
    }

    output << endl;
    output << "**Edges:" << endl;
    for (const auto& pair : this->adjacencyList) {
      output << " " << pair.first << ": ";

      for (const auto& edge : pair.second) {
        output << "(" << edge.first << "," << edge.second << ") ";
      }
      output << endl;
    }

    output << "**************************************************" << endl;
  }

};

